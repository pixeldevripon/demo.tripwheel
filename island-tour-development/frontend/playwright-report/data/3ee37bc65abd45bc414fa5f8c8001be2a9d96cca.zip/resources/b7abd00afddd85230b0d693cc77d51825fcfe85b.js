(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_08qt5bi._.js","static/chunks/0-5o_recharts_es6_util_00a0.i8._.js","static/chunks/0-5o_recharts_es6_component_00g90jo._.js","static/chunks/0-5o_recharts_es6_state_11xg1-1._.js","static/chunks/0-5o_recharts_es6_shape_0.341-j._.js","static/chunks/0-5o_recharts_es6_cartesian_0w2r1zp._.js","static/chunks/0-5o_recharts_es6_09y7dic._.js","static/chunks/node_modules__pnpm_0epxpmj._.js"],
    source: "dynamic"
});
