(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_12bh.__._.js","static/chunks/0s4s_next_09razr4._.js","static/chunks/0nan_framer-motion_dist_es_0v_8x_i._.js","static/chunks/095l_motion-dom_dist_es_0dyajjg._.js","static/chunks/node_modules__pnpm_042d1od._.js"],
    source: "dynamic"
});
