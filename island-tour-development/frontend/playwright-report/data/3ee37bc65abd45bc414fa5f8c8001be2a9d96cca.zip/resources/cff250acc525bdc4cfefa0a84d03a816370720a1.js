(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0n_5f_1._.js","static/chunks/0s4s_next_dist_compiled_next-devtools_index_0wx70uq.js","static/chunks/0s4s_next_dist_compiled_react-dom_04gx0nw._.js","static/chunks/0s4s_next_dist_compiled_react-server-dom-turbopack_0mp5io.._.js","static/chunks/0s4s_next_dist_compiled_0jhy_50._.js","static/chunks/0s4s_next_dist_client_0ke1deq._.js","static/chunks/0s4s_next_dist_server_0e0124s._.js","static/chunks/0s4s_next_dist_08myd7j._.js","static/chunks/0i4a_@swc_helpers_cjs_0hvz.20._.js"],
    source: "entry"
});
