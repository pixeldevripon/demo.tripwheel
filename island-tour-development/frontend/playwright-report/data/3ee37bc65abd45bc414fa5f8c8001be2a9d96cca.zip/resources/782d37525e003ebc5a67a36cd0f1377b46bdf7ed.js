(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules__pnpm_02fi6th._.js","static/chunks/_08ug2g~._.js","static/chunks/[root-of-the-server]__0tl-ydc._.css"],
    source: "dynamic"
});
